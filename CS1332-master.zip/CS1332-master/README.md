# CS1332
Georgia Tech CS1332 Data Structure &amp; Algorithms (Spring 2019)

__HW 1:__ ArrayList

__HW 2:__ Circular Singly-Linked List

__HW 3:__ Stacks & Queues

__HW 4:__ Binary Search Trees

__HW 5:__ MaxHeaps

__HW 6:__ HashMaps

__HW 7:__ AVL Trees

__HW 8:__ Sorting Algorithms

__HW 9:__ Pattern Matching

__HW 10:__ Graph Algorithms
